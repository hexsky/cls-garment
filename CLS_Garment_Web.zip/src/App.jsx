import Home from './components/Home';
import './App.css'

function App() {
  return <Home />;
}

export default App;